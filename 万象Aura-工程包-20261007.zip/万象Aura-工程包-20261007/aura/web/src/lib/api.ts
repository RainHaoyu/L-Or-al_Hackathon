/**
 * 后端客户端（aura/api，默认 http://localhost:8001/api/v1）
 * 设计要点：短超时 + 任何失败静默回退本地引擎（演示日断网双保险）。
 * 类型全部来自 api-types.ts（openapi 自动生成，勿手写）。
 */

import type { AnalyzeRequest, AnalyzeResponse, HealthResponse, ImageRecognitionResponse } from './api-types'

// 构建模式（踩过的坑）：开发默认 localhost:8001；单进程同源部署构建时必须设
// VITE_API_BASE=/api/v1（相对前缀）。切勿置空——BASE 为空串时请求会落在根路径
// /analyze（405 Method Not Allowed），前端静默回退本地引擎、后端计算形同虚设。
const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? 'http://localhost:8001/api/v1'

/**
 * 超时预算（合并口径，不变式由 analyze-timeout.test.ts 与后端 test_llm_budget.py 双向锁定）：
 *   ANALYZE_TIMEOUT[mode] > ENGINE_BUDGET_MS + 后端 llm._BUDGET[mode]（normal/sensitive 6s、anosmia 12s）
 *   normal/sensitive：13s > 5 + 6；anosmia：19s > 5 + 12
 * 后端启动时后台预热引擎基准样本，请求路径的引擎成本远低于 5s 预留。
 */
export const ENGINE_BUDGET_MS = 5_000

/** /analyze 前端超时（毫秒），按模式取值；超时/断网自动回退本地引擎 */
export const ANALYZE_TIMEOUT: Record<NonNullable<AnalyzeRequest['mode']>, number> = {
  normal: 13_000,
  sensitive: 13_000,
  anosmia: 19_000,
}

const TIMEOUT_FAST = 2500
const TIMEOUT_RECOGNITION = 12_000

async function req<T>(path: string, init?: RequestInit, timeout = TIMEOUT_FAST): Promise<T> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), timeout)
  try {
    const r = await fetch(`${BASE}${path}`, { ...init, signal: ctrl.signal })
    if (!r.ok) throw new Error(`HTTP ${r.status}`)
    return (await r.json()) as T
  } finally {
    clearTimeout(timer)
  }
}

export const api = {
  baseUrl: BASE,

  health: () => req<HealthResponse>('/health'),

  recognizeImage: (image: string, filename: string) =>
    req<ImageRecognitionResponse>('/recognition/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image, filename }),
    }, TIMEOUT_RECOGNITION),

  recognizeBarcode: (code: string) =>
    req<ImageRecognitionResponse>('/recognition/barcode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    }),

  analyze: (payload: AnalyzeRequest) =>
    req<AnalyzeResponse>('/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }, ANALYZE_TIMEOUT[payload.mode ?? 'normal']),
}
