"""QRA2 数值回归 + 双引擎 golden 对拍。

背景（2026-10-06 整改）：后端 normal_inv 曾因分母括号缺失把对数正态用量分布
压塌成常数（u=0.9 返回 0.998 而非 1.2816，连符号都会错），P99 被系统性压窄、
风险被低估；beta 逆函数曾用 2001 点查表插值，与前端 80 轮精确二分存在漂移。
本文件把两类缺陷永久钉死在测试层。

golden 文件（golden/qra2-cases.json）由前端 TS 引擎生成（web/scripts/gen_golden.mts），
双端共读同一份；改分布参数或算法后必须重新生成并跑两端测试。
"""
import json
import math
from pathlib import Path

import pytest

from app.modules import qra2

GOLDEN = Path(__file__).resolve().parents[2] / "golden" / "qra2-cases.json"


def test_normal_inv_reference_values():
    """Acklam 标准参照：Φ⁻¹(0.9)=1.2816、Φ⁻¹(0.5)=0、Φ⁻¹(0.1)=-1.2816（符号必须正确）"""
    assert qra2.normal_inv(0.9) == pytest.approx(1.281552, abs=1e-5)
    assert qra2.normal_inv(0.5) == pytest.approx(0.0, abs=1e-9)
    assert qra2.normal_inv(0.1) == pytest.approx(-1.281552, abs=1e-5)
    assert qra2.normal_inv(0.9) == -qra2.normal_inv(0.1)  # 对称性（旧 bug 在此必挂）


def test_sample_cel_distribution_spread():
    """分布形状回归：分位单调 + 离散度真实存在（旧 bug 使 ~95% 样本塌缩到同一点）"""
    s = qra2.sample_cel(5.0)
    assert s["p50"] < s["p90"] < s["p99"]
    # 对数正态 × 面积 × 频率 × Beta 的组合下，P99/P50 比值应在 3~6 之间
    # （旧塌缩 bug 下该比值趋近 1）
    ratio = s["p99"] / s["p50"]
    assert 3.0 < ratio < 6.0, f"P99/P50={ratio}"
    # 点估计落在分布内部（黄金算例：CEL 点估计 5.0，应介于 P50 与 P90 附近）
    point = qra2.point_cel(5.0)
    assert s["p50"] < point * 1.5 and point * 0.5 < s["p99"]


def test_sample_cel_linear_scaling():
    """浓度与聚合是纯线性乘子（因子化缓存的数学前提）"""
    base = qra2.sample_cel(5.0)
    double = qra2.sample_cel(10.0)
    agg = qra2.sample_cel(5.0, aggregate=1.25)
    assert double["p99"] == pytest.approx(base["p99"] * 2, rel=1e-12)
    assert agg["p99"] == pytest.approx(base["p99"] * 1.25, rel=1e-12)


def test_beta_inv_reference():
    """Beta(20,2) 分位：均值 20/22≈0.909，中位数应略高于均值、P90 接近 0.97"""
    assert qra2._beta_inv(0.5) == pytest.approx(0.9214, abs=1e-4)
    assert qra2._beta_inv(0.9) == pytest.approx(0.9744, abs=1e-4)
    assert qra2._beta_inv(0.0) == 0.0 and qra2._beta_inv(1.0) == 1.0


def test_golden_parity_with_frontend():
    """双引擎 golden 对拍：与前端 TS 引擎同种子同输入，分位数一致（rel 1e-6）"""
    payload = json.loads(GOLDEN.read_text(encoding="utf-8"))
    assert qra2.normal_inv(0.9) == pytest.approx(payload["normalInv"]["u09"], rel=1e-9)
    assert qra2._beta_inv(0.5) == pytest.approx(payload["betaInv"]["u05"], abs=1e-6)
    for c in payload["cases"]:
        got = qra2.sample_cel(c["concPct"], seed=c["seed"], aggregate=c["aggregateFactor"])
        for k in ("p50", "p90", "p99"):
            assert got[k] == pytest.approx(c[k], rel=1e-6), (
                f"seed={c['seed']} conc={c['concPct']} agg={c['aggregateFactor']} "
                f"{k}: backend={got[k]!r} golden(ts)={c[k]!r}"
            )


def test_demo_estimate_penalty_path(monkeypatch):
    """演示估计惩罚（H4 回归）：source=demo_estimate → AEL ÷ DEMO_PENALTY 且标 indicative。
    与前端 qra2.test.ts 的同构用例保持字段口径一致（tox.source）。"""
    fake = {"keys": ["测试成分"], "zh": "测试成分", "nesil": 900.0, "demo": True, "k25": None}
    monkeypatch.setattr(qra2.D, "lookup_tox", lambda _name: fake)
    res = qra2.analyze_ingredient("测试成分", 5.0, "healthy")
    assert res["matched"] is True
    assert res["aelEvidence"] == "indicative"
    assert res["ael"] == pytest.approx(900.0 / qra2.D.SAF / qra2.D.DEMO_PENALTY)
    # 对照：文献值不打折
    monkeypatch.setattr(qra2.D, "lookup_tox", lambda _n: {**fake, "demo": False})
    res2 = qra2.analyze_ingredient("测试成分", 5.0, "healthy")
    assert res2["aelEvidence"] == "documented"
    assert res2["ael"] == pytest.approx(9.0)


def test_ifra_gate_branch():
    """IFRA 闸门（M4 回归）：传限值时 high/mid/low 三档判定生效（前端同规则）"""
    res = qra2.analyze_ingredient("d-Limonene", 5.0, "healthy", ifra_limit_pct=5.0)
    assert res["ifraLevel"] == "high" and res["level"] == "high" and res["dominantGate"] == "IFRA 闸门"
    mid = qra2.analyze_ingredient("d-Limonene", 5.0, "healthy", ifra_limit_pct=6.0)
    assert mid["ifraLevel"] == "mid"  # 5.0 >= 6.0*0.8
    low = qra2.analyze_ingredient("d-Limonene", 5.0, "healthy", ifra_limit_pct=20.0)
    assert low["ifraLevel"] == "low"


def test_banned_gate_branch():
    res = qra2.analyze_ingredient("任意", 1.0, "healthy", banned=True)
    assert res["level"] == "high" and res["bannedLevel"] == "high" and res["dominantGate"] == "禁用闸门"


def test_compute_d_bounds():
    assert qra2.compute_d(0, "hot") == 0.0
    d36 = qra2.compute_d(36, "room")
    assert 0 < d36 < 1 and math.isfinite(d36)
    assert qra2.compute_d(12, "hot") > qra2.compute_d(12, "room") > qra2.compute_d(12, "cool")
