#!/bin/bash
# 万象 Aura 一键启动（macOS / Linux）
# 唯一前提：Python 3.11+。首次运行自动建 venv 并离线安装依赖（vendor 为 Windows wheel，
# macOS 上自动回退在线安装/清华镜像）。关闭本窗口即停止服务。
cd "$(dirname "$0")/aura/api" || exit 1

PY=python3
command -v python3 >/dev/null 2>&1 || PY=python

if [ ! -f ".venv/.deps_ok" ]; then
  echo "首次运行：创建虚拟环境并安装依赖，约 1 分钟..."
  [ -x ".venv/bin/python" ] || "$PY" -m venv .venv || { echo "venv 创建失败"; exit 1; }
  .venv/bin/python -m pip install -r requirements.txt -q \
    || .venv/bin/python -m pip install -r requirements.txt -q -i https://pypi.tuna.tsinghua.edu.cn/simple \
    || { echo "依赖安装失败，请检查网络"; exit 1; }
  touch .venv/.deps_ok
fi

PORT=8001
echo ""
echo "============================================================"
echo "  万象 Aura 启动中：http://127.0.0.1:${PORT}"
echo "  页面与 API 由同一进程提供；Ctrl+C 停止"
echo "============================================================"
echo ""
( sleep 2; open "http://127.0.0.1:${PORT}/" 2>/dev/null || xdg-open "http://127.0.0.1:${PORT}/" 2>/dev/null ) &
exec .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port "$PORT"
