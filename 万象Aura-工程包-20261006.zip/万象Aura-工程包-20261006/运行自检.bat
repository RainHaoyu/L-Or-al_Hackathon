@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 万象 Aura - 运行自检
cd /d "%~dp0aura\api"

rem ============================================================
rem   运行自检：跑后端 pytest 全量（26 条，约 10 秒）。
rem   覆盖：黄金算例对齐 / 双引擎 golden 对拍 / 输入校验 /
rem         mock 识别确定性 / 错误隔离 / 降级兜底。
rem   测试已做网络隔离，不会外呼任何大模型接口。
rem ============================================================

set "PYC=py"
py --version >nul 2>nul || set "PYC="
if not defined PYC (
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYC set "PYC=%%i"
)
if not defined PYC (
  echo [错误] 未检测到 Python，请先安装 3.11+。
  pause
  exit /b 1
)

if not exist ".venv\.deps_ok" (
  echo 尚未安装依赖，先复用一键启动的引导流程...
  call "%~dp0一键启动.bat" >nul 2>&1
)

echo 运行 pytest...
".venv\Scripts\python.exe" -m pytest tests/ -v --color=yes
echo.
if errorlevel 1 (
  echo [失败] 存在未通过用例，请把上方输出发给团队。
) else (
  echo [通过] 全部用例绿色，工程包状态健康。
)
pause
