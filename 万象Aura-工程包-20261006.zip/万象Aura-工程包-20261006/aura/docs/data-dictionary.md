# 数据字典（src/data/，前后端共读）

> 生成：`cd aura/web && python3 scripts/build_data.py`（幂等，重跑后产物应零 diff）。
> 数据层原始文件在本仓库**上一级** `数据层/`，需另行获取后放置（见 web/README「数据层获取」）。

| 文件 | 条数 | 关键字段（含义/单位） | 来源 |
|---|---|---|---|
| perfumes.json | 12+黄金算例 | pyramid[].weight=层权重%；notes[].family=12香调族键；concBasis=浓度口径（文献典型值，非逐款实测）；keywords=品鉴关键词 | 12款经典香水分析.docx |
| ifra.json | limits 20 / banned 9 / natural 2 | limitPct=Cat4 成品上限（w/w %）；banned[].casValid=false 表示源表 CAS 错位置空待核；casSource=纠错前原值（审计） | IFRA 51st Amendment Cat4 xlsx |
| tox.json | 22 | nesil=μg/cm²（null=demo 估计→÷demoPenalty）；source=文献系（逐条报告编号待补，TODO 2-1）；k25=成分级氧化速率（25°C/天，Q10 模型） | RIFM/Api2008 系 |
| allergens26.json | 26 | note=Ⅳ型致敏备注；阈值口径：驻留类 >0.01% 需标注 | 表格26种致敏香料.xlsx |
| ige.json | 10 | category（树脂/净油）；risk（中/中‑低/低）→ 界面黄/绿；IgE Ⅰ 型速发 | IgE致敏原表格.xlsx |
| ingredients.json | 160 | source: natural/synthetic/fragrance；CAS 已归一（去空格） | 三个 CAS 词典 xlsx |
| materials.json | 天然72+合成76 | synthetic 按 8 大类归档 | 香水成分数据及过敏香料.docx |

**判定数值口径**：AEL=NESIL÷SAF（μg/cm²）；CEL 点估计=浓度×0.5×100×2×1.0（μg/cm²/day）；P50/P90/P99=LHS 万次分位（固定种子 20261005）；氧化 D=1−exp(−k25·Q10^((T−25)/10)·(1+L)·t)，阈值 0.2/0.5。

**香调口径（5-1 决策）**：现行 **12 香调**（citrus/floral/woody/aquatic/oriental/leather/chypre/fougere/fruity/green/gourmand/aromatic），名单、HEX 色值与场景全部来自《香型HEX色值及对应画面效果.docx》。早期文档的"7 香调"为该文件引入前的过渡实现，**已废弃**；如再调整香调集合，必须同步改 `FAMILIES`（前端 lib/aura.ts + 后端 app/data.py）与两处映射表。

**双引擎同步警示（3-1）**：QRA2 算法在 `web/src/lib/qra2/`（TS）与 `api/app/modules/qra2.py`（Python）双实现——黄金算例/分位/闸门由两侧测试锁定。**改任一侧必须同步另一侧并重跑两端测试**（`npm test` + `pytest`）。数据类常量请改共享 JSON，勿改代码内嵌。
