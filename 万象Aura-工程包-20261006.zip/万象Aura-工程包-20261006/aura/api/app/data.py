"""共享数据层：直接消费 aura/web/src/data/*.json（前端构建管线产物，单一数据源）。

- 数据目录可用 AURA_DATA_DIR 覆盖（默认 ../web/src/data），API 包可独立部署（P2-4）
- 加载失败给出可定位的启动错误（此前 JSON 缺失时 import 期裸抛 FileNotFoundError）
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

API_ROOT = Path(__file__).resolve().parents[1]                          # aura/api
DATA_DIR = Path(os.environ.get("AURA_DATA_DIR") or API_ROOT.parent / "web" / "src" / "data")

FAMILIES: dict[str, dict[str, Any]] = {
    "citrus": {"name": "柑橘调", "main": "#FFA500", "accents": ["#FFDD00", "#B4D26A"], "scene": "剥开鲜橙的瞬间，精油光点迸溅的果园", "mood": "清新、活力", "shape": "光珠"},
    "floral": {"name": "花香调", "main": "#FFB6C1", "accents": ["#FFBC97", "#C5E0B4"], "scene": "春日花园，柔粉花瓣伴着蜜桃果肉", "mood": "温柔、浪漫", "shape": "花瓣"},
    "woody": {"name": "木质调", "main": "#6B4423", "accents": ["#8A6F56", "#7A8868"], "scene": "幽静森林，原木与树脂的气息", "mood": "沉稳、温暖", "shape": "叶片"},
    "aquatic": {"name": "水生调", "main": "#A1C8D7", "accents": ["#C2D2D9", "#94B8B2"], "scene": "薄雾笼罩的平静湖面，淡淡海风", "mood": "清新、辽阔", "shape": "水珠"},
    "oriental": {"name": "东方调", "main": "#965327", "accents": ["#782C20", "#B87333"], "scene": "琥珀、树脂与辛香交织的暖调宫殿", "mood": "浓郁、神秘", "shape": "花瓣"},
    "leather": {"name": "皮革调", "main": "#4A3628", "accents": ["#634737", "#A88C7E"], "scene": "烟熏气息的复古鞣制工坊", "mood": "醇厚、不羁", "shape": "果实"},
    "chypre": {"name": "西普调", "main": "#706C58", "accents": ["#506248", "#8C4743"], "scene": "秋日山林，青苔与岩石相互缠绕", "mood": "优雅、克制", "shape": "叶片"},
    "fougere": {"name": "馥奇调", "main": "#748C67", "accents": ["#9F91C8", "#A08C6D"], "scene": "雨后林间草地，薰衣草与苔藓", "mood": "经典、平衡", "shape": "针叶"},
    "fruity": {"name": "果香调", "main": "#D96058", "accents": ["#FFB3A0", "#8C4743"], "scene": "挂满浆果的果园，水润饱满", "mood": "鲜活、明快", "shape": "果实"},
    "green": {"name": "绿叶调", "main": "#87B36B", "accents": ["#597C47", "#B2C997"], "scene": "清晨刚采摘的鲜草与青枝叶", "mood": "自然、清爽", "shape": "叶片"},
    "gourmand": {"name": "美食调", "main": "#C87941", "accents": ["#F8EAD8", "#5C3317"], "scene": "暖烘烘的甜品铺，焦糖与可可", "mood": "甜美、温暖", "shape": "果实"},
    "aromatic": {"name": "芳香调", "main": "#697C57", "accents": ["#9484B7", "#A39478"], "scene": "阳光晾晒的草本药草，青苦干爽", "mood": "干爽、草本", "shape": "针叶"},
}


def _load(name: str) -> Any:
    path = DATA_DIR / name
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"[aura.data] 数据文件缺失：{path}\n"
              f"  数据层来自前端构建管线（web/src/data）；独立部署时可设 AURA_DATA_DIR 指向数据目录。",
              file=sys.stderr)
        raise
    except json.JSONDecodeError as exc:
        print(f"[aura.data] 数据文件损坏：{path}（{exc}）——请重跑 web/scripts/build_data.py", file=sys.stderr)
        raise


PERFUMES: list[dict[str, Any]] = _load("perfumes.json")["perfumes"]
IFRA: dict[str, Any] = _load("ifra.json")
DICT_ENTRIES: list[dict[str, Any]] = _load("ingredients.json")["entries"]
EU26: list[dict[str, Any]] = _load("allergens26.json")["items"]
IGE: list[dict[str, Any]] = _load("ige.json")["items"]
MATERIALS: dict[str, Any] = _load("materials.json")

# 共享毒理表（前端 nesil.ts 共读同一份；SAF/DEMO_PENALTY 以 tox.json 为准，勿在代码里重复定义）
_TOX_FILE = _load("tox.json")
SAF = int(_TOX_FILE["saF"])
DEMO_PENALTY = int(_TOX_FILE["demoPenalty"])
TOX: list[dict[str, Any]] = _TOX_FILE["items"]

# 黄金算例教学样本（与前端 aura.ts GOLDEN_CASE 同源；点估计口径 = v3 报告算例）
PERFUMES.append({
    "id": "golden-case", "no": "13", "brand": "黄金算例", "name": "柠檬烯 5% 样本", "en": "Limonene 5%",
    "familyZh": "柑橘调", "familyKey": "citrus", "concentration": "教学样本",
    "keywords": "柠檬烯、点估计、可复算", "families": ["citrus", "green", "woody"],
    "pyramid": [
        {"layer": "前调", "weight": 40, "notes": [{"name": "柠檬烯", "family": "citrus"}]},
        {"layer": "中调", "weight": 35, "notes": [{"name": "柠檬叶", "family": "green"}]},
        {"layer": "后调", "weight": 25, "notes": [{"name": "柠檬木", "family": "woody"}]},
    ],
    "ingredients": ["柠檬烯"],
    "radar": [{"dim": "清新", "v": 10}, {"dim": "甜度", "v": 2}, {"dim": "浓郁", "v": 3},
              {"dim": "温暖", "v": 3}, {"dim": "持久", "v": 4}],
    "synesthesia": "刚剥开的柠檬皮，汁水溅在晨光里，干净得只剩一点木。",
    "synthetic": True,
})


def get_perfume(pid: str) -> dict[str, Any] | None:
    return next((p for p in PERFUMES if p["id"] == pid), None)


def norm(s: str) -> str:
    """统一归一化（analyzer 等模块复用，避免各处重复实现）"""
    return "".join(ch for ch in s.lower() if ch.isalnum())


def composition(perfume: dict[str, Any]) -> list[dict[str, Any]]:
    """香调组成聚合：层权重 × 层内等分 → 香型族占比降序（与前端 aura.ts compositionMix 同实现；
    analyzer 可视化与 llm Prompt 共用，放在数据层避免模块间循环依赖）"""
    agg: dict[str, float] = {}
    for layer in perfume.get("pyramid", []):
        n = max(len(layer["notes"]), 1)
        for note in layer["notes"]:
            agg[note["family"]] = agg.get(note["family"], 0) + layer["weight"] / n
    return sorted(({"family": k, "share": v} for k, v in agg.items()), key=lambda x: -x["share"])


def lookup_tox(name: str) -> dict[str, Any] | None:
    """最长优先匹配（按「实际命中的键长」排序，防英文长键劫持中文命中，改进清单 1-5）"""
    n = norm(name)
    best, best_len = None, 0
    for t in TOX:
        for k in t["keys"]:
            nk = norm(k)
            min_len = 4 if any(c.isascii() and c.isalpha() for c in k) else 2
            if len(nk) >= min_len and nk in n and len(nk) > best_len:
                best, best_len = t, len(nk)
    return best
