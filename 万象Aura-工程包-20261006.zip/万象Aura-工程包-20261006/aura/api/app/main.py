"""FastAPI 入口：/api/v1（统一信封 data + meta）。

- .env 自动加载（P1-3：此前声明了 python-dotenv 却从未调用，配了 Key 也静默落 mock）
- CORS 按 AURA_ENV 区分：dev 全开（本地联调），prod 走白名单（P2-5）
- 全局异常处理器：未捕获异常也保持统一信封（P1-2，演示日 500 不再裸露堆栈）
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import data as D
from . import schemas as S
from .modules import analyzer, recognition

# .env 优先级低于进程环境变量；文件不存在时静默跳过
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)

ENV = os.environ.get("AURA_ENV", "dev")
# 生产环境收敛 CORS；开发环境保持全开便于本地联调
_ORIGINS = ["*"] if ENV == "dev" else [
    o.strip() for o in os.environ.get("AURA_CORS_ORIGINS", "").split(",") if o.strip()
]

app = FastAPI(title="万象 Aura API", version="1.0.0",
              description="赛道三「无界体验家」双核心：QRA2 预警 + 香味可视化（数据层与前端共享）")
app.add_middleware(CORSMiddleware, allow_origins=_ORIGINS, allow_methods=["*"], allow_headers=["*"])

LOG = logging.getLogger("aura.api")


@app.exception_handler(Exception)
async def unhandled_exception_handler(_req: Request, exc: Exception) -> JSONResponse:
    """兜底异常 → 统一信封 500（不向客户端裸露堆栈；日志留全量线索）"""
    LOG.exception("未捕获异常：%s: %s", type(exc).__name__, exc)
    return JSONResponse(status_code=500, content={
        "data": None,
        "meta": {"engine": analyzer.ENGINE_VERSION, "error": f"服务内部错误（{type(exc).__name__}）"},
    })


@app.get("/api/v1/health", response_model=S.HealthResponse)
def health() -> dict:
    return {"data": {"status": "ok", "engine": analyzer.ENGINE_VERSION,
                     "perfumes": len(D.PERFUMES), "ifra_limits": len(D.IFRA["limits"]),
                     "ifra_banned": len(D.IFRA["banned"]), "dictEntries": len(D.DICT_ENTRIES),
                     "eu26": len(D.EU26), "ige": len(D.IGE),
                     "materials": len(D.MATERIALS["natural"]) + int(D.MATERIALS.get("syntheticCount", 0))},
            "meta": {"engine": analyzer.ENGINE_VERSION}}


@app.get("/api/v1/products", response_model=S.ProductsResponse)
def products(q: str = "", limit: int = Query(8, ge=1, le=50)) -> dict:
    items = recognition._fuzzy_search(q, limit)
    return {"data": [{"id": p["id"], "brand": p["brand"], "name": p["name"], "en": p.get("en", ""),
                      "familyZh": p.get("familyZh", ""), "concentration": p.get("concentration", "")}
                     for p in items],
            "meta": {"engine": analyzer.ENGINE_VERSION}}


@app.post("/api/v1/recognition/image", response_model=S.ImageRecognitionResponse)
def recognize_image(req: S.ImageRequest):
    try:
        b64, filename = recognition.normalize_image(req.image)
    except ValueError as exc:
        return JSONResponse(status_code=422, content={
            "data": None, "meta": {"engine": analyzer.ENGINE_VERSION, "error": f"图像格式错误：{exc}"},
        })
    result = recognition.get_vision_provider().recognize_image(b64, filename)
    return {"data": result, "meta": {"engine": analyzer.ENGINE_VERSION}}


@app.post("/api/v1/recognition/barcode", response_model=S.ImageRecognitionResponse)
def recognize_barcode(req: S.BarcodeRequest) -> dict:
    result = recognition.recognize_barcode(req.code)
    return {"data": result, "meta": {"engine": analyzer.ENGINE_VERSION}}


@app.post("/api/v1/analyze", response_model=S.AnalyzeResponse)
def analyze(req: S.AnalyzeRequest):
    result = analyzer.analyze(req.model_dump())
    if result["data"] is None:
        # 未知产品：404 + 统一信封（此前 200 + data:null，语义弱且前端必须人人记得查 meta.error）
        return JSONResponse(status_code=404, content=result)
    return result


# ---- 前端静态托管（工程包开包即用：dist 存在时同一进程同时服务 API 与页面）----
# dist 由 `npm run build`（工程包构建时 VITE_API_BASE 置空 → 同源相对请求）产出；
# 开发模式（vite dev server 5173）不受影响——dist 不存在时本段整体不生效。
_DIST_DIR = Path(os.environ.get("AURA_WEB_DIST") or D.API_ROOT.parent / "web" / "dist")

if _DIST_DIR.is_dir():
    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    _DIST_RESOLVED = _DIST_DIR.resolve()

    @app.get("/", include_in_schema=False)
    def _index() -> FileResponse:
        return FileResponse(_DIST_DIR / "index.html")

    @app.get("/{full_path:path}", include_in_schema=False)
    def _spa(full_path: str) -> FileResponse:
        """静态资源直出；其余路径（/report、/vision 等客户端路由）回退 index.html。
        显式 API 路由注册在前，不会被本兜底遮蔽。"""
        candidate = (_DIST_DIR / full_path).resolve()
        if full_path and candidate.is_file() and _DIST_RESOLVED in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(_DIST_DIR / "index.html")
