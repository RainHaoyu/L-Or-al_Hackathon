"""测试网络隔离（改进清单 1-3）：无论开发机是否配置 DASHSCOPE_API_KEY，
所有用例都不发真实外部请求——百炼调用一律落 mock/模板路径。"""
import pytest


@pytest.fixture(autouse=True)
def _no_dashscope(monkeypatch):
    monkeypatch.delenv("DASHSCOPE_API_KEY", raising=False)
