/**
 * 生成 QRA2 双引擎 golden 对拍文件（aura/golden/qra2-cases.json）。
 * 以 TS 引擎（修复后的正确实现）为基准；后端 pytest 与前端 vitest 各自断言同一份文件。
 * 用法：cd aura/web && node_modules/.bin/vite-node scripts/gen_golden.mts
 * 改分布参数/算法后必须重新生成，并同步跑两端测试。
 */
import { writeFileSync, mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { sampleCEL, normalInv, betaInv } from '../src/lib/qra2/distributions'

const cases = [
  { seed: 20261005, concPct: 5.0, aggregateFactor: 1.0 },
  { seed: 20261005, concPct: 0.8, aggregateFactor: 1.0 },
  { seed: 20261005, concPct: 5.0, aggregateFactor: 1.25 },
  { seed: 42, concPct: 12.0, aggregateFactor: 1.0 },
  { seed: 7, concPct: 0.3, aggregateFactor: 2.0 },
]

const out = cases.map((c) => {
  const s = sampleCEL(c)
  return { ...c, p50: s.p50, p90: s.p90, p99: s.p99 }
})

const payload = {
  note: 'QRA2 双引擎 golden 对拍（TS 引擎生成；pytest/vitest 共读；rel 容差 1e-6）',
  normalInv: { u09: normalInv(0.9), u05: normalInv(0.5), u01: normalInv(0.1) },
  betaInv: { u05: betaInv(0.5, 20, 2), u09: betaInv(0.9, 20, 2) },
  cases: out,
}

const dest = resolve(dirname(fileURLToPath(import.meta.url)), '../../golden/qra2-cases.json')
mkdirSync(dirname(dest), { recursive: true })
writeFileSync(dest, JSON.stringify(payload, null, 2) + '\n')
console.log(`written: ${dest}`)
for (const c of out) {
  console.log(`seed=${c.seed} conc=${c.concPct} agg=${c.aggregateFactor}: p50=${c.p50.toFixed(6)} p90=${c.p90.toFixed(6)} p99=${c.p99.toFixed(6)}`)
}
