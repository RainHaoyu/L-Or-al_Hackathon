/**
 * 双端 verdict 一致性对拍（P1-5 全量核对）：
 * 前端 evaluate() 与后端 /analyze verdict.level 在 13 款 × 5 群 × 3 情境矩阵上逐格一致。
 * 用法：后端起在 :8017 后，cd aura/web && node_modules/.bin/vite-node scripts/parity_matrix.mts
 */
import { evaluate, PERFUMES, computeD, STORAGE_ENV, type PopulationKey } from '../src/lib/aura'

const BASE = 'http://127.0.0.1:8017/api/v1/analyze'

async function main() {
  let total = 0
  let mismatch = 0
  for (const p of PERFUMES) {
    for (const pop of ['healthy', 'sensitive', 'pregnant', 'rhinitis', 'anosmic'] as PopulationKey[]) {
      for (const [months, st] of [[0, 'cool'], [14, 'room'], [36, 'hot']] as const) {
        const d = computeD(months, STORAGE_ENV[st])
        const front = evaluate(pop, p.id, d).level
        const r = await fetch(BASE, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ product_id: p.id, population: pop, opened_months: months, storage: st }),
        })
        const body = await r.json()
        const back = body.data?.verdict?.level as string | undefined
        total++
        if (front !== back) {
          mismatch++
          console.log(`不一致: ${p.id} × ${pop} × ${months}月/${st}: 前端=${front} 后端=${back}`)
        }
      }
    }
  }
  console.log(`矩阵 ${total} 格，verdict 不一致 ${mismatch} 格`)
  process.exit(mismatch === 0 ? 0 : 1)
}
void main()
