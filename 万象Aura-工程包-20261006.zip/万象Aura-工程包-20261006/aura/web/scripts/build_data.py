#!/usr/bin/env python3
"""万象 Aura · 数据层 → 前端 JSON 管线（纯标准库，幂等可重跑）

输入：数据层/ 下 5 个真实数据文件
  - 12款经典香水分析.docx      → src/data/perfumes.json（12 款真实香水）
  - IFRA 51st Amendment Cat4香水禁用清单.xlsx → src/data/ifra.json（限量20/禁用9/天然2）
  - 天然香料cas.xlsx / 合成香料CAS.xlsx / 香精 水溶性及油溶性香精CAS.xlsx → src/data/ingredients.json

用法：python3 scripts/build_data.py
"""

import html
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent            # aura/web
WS = ROOT.parent.parent                                   # 欧莱雅黑客松
DATA_DIR = WS / "数据层"
OUT_DIR = ROOT / "src" / "data"
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------- docx 段落
def docx_paragraphs(path: Path):
    """返回 [(style, text)]，style 为标题样式 id 或 ''（正文）；<w:tab/> 转为 \\t"""
    xml = zipfile.ZipFile(path).read("word/document.xml").decode("utf-8")
    xml = re.sub(r"<w:tab\b[^>]*/>", "<w:t>\t</w:t>", xml)
    out = []
    for p in re.split(r"</w:p>", xml):
        m = re.search(r'<w:pStyle w:val="([^"]+)"', p)
        style = m.group(1) if m else ""
        text = "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", p))
        if text.strip():
            out.append((style, text.strip()))
    return out


# ---------------------------------------------------------------- xlsx 读取
def xlsx_rows(path: Path):
    """返回 [{列字母: 文本}] 列表（合并 sharedStrings / inlineStr / 数字）"""
    z = zipfile.ZipFile(path)
    ss: list[str] = []
    if "xl/sharedStrings.xml" in z.namelist():
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall("m:si", NS):
            ss.append("".join(t.text or "" for t in si.iter(M + "t")))
    sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
    rows = []
    for row in sheet.iter(M + "row"):
        cells = {}
        for c in row.findall(M + "c"):
            ref = c.get("r", "")
            cm = re.match(r"([A-Z]+)", ref)
            if not cm:
                continue
            col = cm.group(1)
            t = c.get("t")
            if t == "inlineStr":
                is_el = c.find(M + "is")
                val = "".join(x.text or "" for x in is_el.iter(M + "t")) if is_el is not None else ""
            else:
                v = c.find(M + "v")
                val = v.text if v is not None else ""
                if val and t == "s":
                    iv = int(val)
                    val = ss[iv] if 0 <= iv < len(ss) else val
            if val:
                cells[col] = val
        rows.append(cells)
    return rows


def docx_tables(path: Path):
    """返回 [[cell文本, ...], ...]（按行展平的表格）"""
    xml = zipfile.ZipFile(path).read("word/document.xml").decode("utf-8")
    tables = []
    for tbl in re.findall(r"<w:tbl>.*?</w:tbl>", xml, re.S):
        rows_out = []
        for tr in re.findall(r"<w:tr[ >].*?</w:tr>", tbl, re.S):
            cells = []
            for tc in re.findall(r"<w:tc>.*?</w:tc>", tr, re.S):
                text = "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", tc))
                cells.append(text.strip())
            if any(cells):
                rows_out.append(cells)
        if rows_out:
            tables.append(rows_out)
    return tables


# ---------------------------------------------------------------- 香材 → 香型族推断
FAMILY_RULES = [  # (familyKey, 关键词列表)——顺序即优先级：具体先于泛化
    ("leather", ["皮革"]),
    ("chypre", ["橡木苔", "苔藓", "橡苔"]),
    ("aquatic", ["海盐", "海藻", "海洋", "水生", "黄葵"]),
    ("citrus", ["香柠檬", "佛手柑", "柠檬", "柑橘", "苦橙叶", "苦橙", "橙皮", "西柚", "葡萄柚", "橙子"]),
    ("fruity", ["桃", "梨", "甜瓜", "香瓜", "浆果", "苹果", "李子", "杏仁", "果"]),
    ("gourmand", ["香草", "可可", "巧克力", "零陵香豆", "香豆素", "干果", "焦糖", "美食"]),
    ("floral", ["玫瑰", "茉莉", "依兰", "鸢尾", "橙花", "晚香玉", "铃兰", "紫罗兰", "天竺葵", "乙醛", "醛", "花"]),
    ("woody", ["雪松", "檀香", "香根草", "广藿香", "柏木", "愈创木", "乌木", "木"]),
    ("oriental", ["琥珀", "安息香", "乳香", "没药", "树脂", "辛香", "藏红花", "龙涎", "小豆蔻", "香荚兰"]),
    ("fougere", ["薰衣草", "馥奇"]),
    ("aromatic", ["麝香", "烟草", "茶", "鼠尾草", "迷迭香", "草本", "药草", "薄荷", "樟"]),
    ("green", ["青草", "绿叶", "叶子", "叶"]),
]

# 文档 12 类香调 → 前端 12 香型族（键两侧统一去掉「调」字后匹配）
FAMILY_MAP = {
    "柑橘馥奇": "fougere", "醛香花香": "floral", "西普": "chypre", "东方琥珀": "oriental",
    "美食": "gourmand", "木质馥奇": "fougere", "水生": "aquatic", "皮革": "leather",
    "白花香": "floral", "木质乌木": "woody", "芳香草本": "aromatic", "果香花香": "fruity",
}


def fam_key(zh: str) -> str:
    return zh[:-1] if zh.endswith("调") else zh


def infer_note_family(note: str, fallback: str) -> str:
    for fam, kws in FAMILY_RULES:
        if any(k in note for k in kws):
            return fam
    return fallback


def slugify(en: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", en.lower()).strip("-")
    return s or "perfume"


# ---------------------------------------------------------------- 1) 12 款香水
def build_perfumes():
    paras = [(s, html.unescape(t)) for s, t in docx_paragraphs(DATA_DIR / "12款经典香水分析.docx")]
    # 末尾「香调家族汇总表」为制表符段落（或表格）→ {序号: 关键词}
    keywords = {}
    for _s, text in paras:
        if "\t" in text:
            # 分隔符逐行混杂（tab/双空格/单空格），首列为序号、末列为关键词
            cols = [c.strip() for c in re.split(r"\t+|\s{2,}", text) if c.strip()]
            if len(cols) >= 4 and cols[0].isdigit():
                keywords[cols[0]] = cols[-1]
    for table in docx_tables(DATA_DIR / "12款经典香水分析.docx"):
        for cells in table:
            if len(cells) >= 5 and cells[0].strip().isdigit():
                keywords[cells[0].strip()] = cells[4].strip()

    perfumes = []
    cur = None
    for style, text in paras:
        m = re.match(r"^(\d+)\s*[｜|]\s*(.+?)\s*[（(]\s*(.+?)\s*[｜|]\s*(.+?)\s*[）)]$", text)
        if m:
            no, name_part, fam_zh, fam_en = m.groups()
            brand = next((b for b in ["香奈儿", "蒂普提克", "祖玛珑", "莱俪", "迪奥", "娇兰", "MFK", "TF", "欧珑"]
                          if name_part.startswith(b)), name_part.split(" ")[0])
            rest = name_part[len(brand):].strip()
            tokens = rest.split()
            en_tokens, zh_tokens = [], []
            for tk in tokens:
                if re.match(r"^[A-Za-z]", tk) and not en_tokens and zh_tokens:
                    en_tokens.append(tk)
                elif en_tokens:
                    en_tokens.append(tk)
                else:
                    zh_tokens.append(tk)
            zh_name = " ".join(zh_tokens) or rest
            en_name = " ".join(en_tokens)
            fallback = FAMILY_MAP.get(fam_key(fam_zh), "floral")
            cur = {
                "id": slugify(en_name or zh_name), "no": no, "brand": brand,
                "name": zh_name, "en": en_name,
                "familyZh": fam_zh, "familyEn": fam_en,
                "familyKey": fallback,
                "concentration": "", "pyramidRaw": {}, "ingredients": [],
                "keywords": keywords.get(no, ""), "demoNote": "",
            }
            perfumes.append(cur)
            continue
        if cur is None:
            continue
        for field in ("浓度", "前调", "中调", "后调", "成分清单", "成分"):
            if text.startswith(field):
                val = text[len(field):].lstrip("：: ").strip()
                if field == "浓度":
                    cur["concentration"] = val
                elif field in ("前调", "中调", "后调"):
                    cur["pyramidRaw"][field] = [n.strip() for n in re.split(r"[、,，]", val) if n.strip()]
                else:
                    cur["ingredients"] = [n.strip() for n in re.split(r"[、,，;；]", val) if n.strip()]
                break
        else:
            if text.startswith(("Demo", "demo", "备注")):
                cur["demoNote"] = text.lstrip("Demo备注：: demo ").strip()
            elif not cur["demoNote"] and not any(text.startswith(x) for x in ("香调家族", "浓度标准")):
                if cur.get("ingredients") and not cur["demoNote"] and len(text) > 12:
                    cur["demoNote"] = text

    # pyramid → 带族推断的结构化输出
    out = []
    for p in perfumes:
        layers = []
        for i, layer in enumerate(("前调", "中调", "后调")):
            notes = p["pyramidRaw"].get(layer, [])
            n = len(notes) or 1
            layers.append({
                "layer": layer,
                "weight": [24, 46, 30][i],
                "notes": [{"name": x, "family": infer_note_family(x, p["familyKey"])} for x in notes],
            })
        fam_counts = {}
        for ly in layers:
            for nt in ly["notes"]:
                key = f"{ly['layer']}|{nt['family']}"
                fam_counts[nt["family"]] = fam_counts.get(nt["family"], 0) + ly["weight"] / max(len(ly["notes"]), 1)
        families = [k for k, _ in sorted(fam_counts.items(), key=lambda kv: -kv[1])]
        out.append({
            "id": p["id"], "no": p["no"], "brand": p["brand"], "name": p["name"], "en": p["en"],
            "familyZh": p["familyZh"], "familyEn": p["familyEn"],
            "familyKey": p["familyKey"], "families": families[:4] or [p["familyKey"]],
            "concentration": p["concentration"], "concBasis": "文献典型值（非逐款实测）",
            "pyramid": layers,
            "ingredients": p["ingredients"], "keywords": p["keywords"], "demoNote": p["demoNote"],
        })
    return {
        "source": "数据层/12款经典香水分析.docx",
        "concentrationStandards": {"Parfum": "20–40%", "EDP": "15–20%", "EDT": "5–15%", "EDC": "2–5%"},
        "perfumes": out,
    }


# ---------------------------------------------------------------- 2) IFRA 三表
# CAS 校验位验证 + 禁用表人工核对纠错（源 xlsx 禁用区 H/I/J 整体错位一行，
# 部分拼出的 CAS 张冠李戴且部分能通过校验位，故校验位 + 纠错表双闸，非法一律置 null 不静默落盘）
def cas_checksum_ok(cas: str) -> bool:
    digits = re.sub(r"\D", "", cas or "")
    if len(digits) < 3:
        return False
    body, check = digits[:-1], int(digits[-1])
    total = sum(int(d) * (i + 1) for i, d in enumerate(reversed(body)))
    return total % 10 == check


BANNED_CAS_CORRECTIONS = {
    "葵子麝香": "83-66-9",       # musk ambrette
    "二甲苯麝香": "81-15-2",     # musk xylene
    "海葵醛": "31906-04-4",      # Lyral / HICC
    "酮麝香": "81-14-1",         # musk ketone（源表即正确，复核保留）
    "铃兰醛": "80-54-6",         # Lilial（源表即正确，复核保留）
}
BANNED_CAS_UNVERIFIED = {"薄荷内酯", "当归根油"}  # 源表 CAS 疑似错位且无把握，显式置空待人工核对


def parse_limit_pct(raw) -> float | None:
    """限值单元格解析："<0.02%" 之类带符号限值取数值上界（限量本身即上限语义，方向保守）；
    真无法解析才置 None 并告警——此前 float() 直接丢弃会按「无限值」宽松判定（危险方向）。"""
    s = str(raw or "").strip().replace("%", "").replace("％", "")
    m = re.match(r"^[<>≤]?\s*(\d+(?:\.\d+)?)", s)
    if m:
        return float(m.group(1))
    if s:
        print(f"WARN: 限值单元格无法解析 {raw!r}，置 None（该成分按无限值处理，请人工核对源表）")
    return None


def build_ifra():
    rows = xlsx_rows(DATA_DIR / "IFRA 51st Amendment Cat4香水禁用清单.xlsx")
    limits, banned, natural = [], [], []
    for cells in rows:
        # 表1 限量（B–F）
        if cells.get("B") and cells.get("C"):
            zh_en = cells["C"]
            zh, en = zh_en, cells.get("D", "")
            m = re.match(r"^(.*?)\s{2,}(.+)$", zh_en)  # d-柠檬烯：中英挤在一格
            if m and not cells.get("D"):
                zh, en = m.group(1).strip(), m.group(2).strip()
            limit = parse_limit_pct(cells.get("E", ""))
            limits.append({"cas": cells.get("B", "").strip(), "zh": zh.strip(), "en": en.strip(),
                           "limitPct": limit, "note": cells.get("F", "").strip()})
        # 表2 禁用（H–L）：CAS 碎片修复
        raw = [cells.get(c, "") for c in ("H", "I", "J", "K", "L")]
        vals = [v.strip() for v in raw if v.strip()]
        if vals:
            cas, idx = None, 0
            pieces = []
            while idx < len(vals) and re.fullmatch(r"\d{1,7}", vals[idx]):
                pieces.append(vals[idx]); idx += 1
            if pieces:
                cas = "-".join(pieces)
            rest = vals[idx:]
            if rest:
                zh2 = rest[0]
                tail = rest[1] if len(rest) > 1 else ""
                segs = [s.strip() for s in re.split(r"[\n\r]+", tail) if s.strip()]
                en2 = segs[0] if segs else ""
                kind = next((s for s in segs if "禁" in s), "完全禁用")
                reason = segs[-1] if len(segs) > 1 else ""
                if zh2 and not zh2.isdigit():
                    cas_source = cas
                    cas_valid = cas is not None and cas_checksum_ok(cas)
                    if zh2 in BANNED_CAS_CORRECTIONS and BANNED_CAS_CORRECTIONS[zh2] != cas:
                        cas = BANNED_CAS_CORRECTIONS[zh2]
                        cas_valid = cas_checksum_ok(cas)
                    if zh2 in BANNED_CAS_UNVERIFIED:
                        cas, cas_valid = None, False
                    if cas is not None and not cas_valid:
                        print(f"WARN: 禁用项「{zh2}」CAS「{cas}」校验位非法，置空待人工核对")
                        cas = None
                    banned.append({"cas": cas, "casSource": cas_source, "casValid": cas_valid,
                                   "zh": zh2, "en": en2, "control": kind, "reason": reason})
        # 表3 天然精油（N–Q）
        if cells.get("N") and cells.get("O"):
            lim = parse_limit_pct(cells.get("P", ""))
            natural.append({"zh": cells["N"].strip(), "en": cells.get("O", "").strip(),
                            "limitPct": lim, "note": cells.get("Q", "").strip()})
    # 过滤误入的表头/空行 + 去重；截断时显式告警（静默丢行不可接受）
    def trunc_tagged(items: list, cap: int, label: str) -> list:
        if len(items) > cap:
            print(f"WARN: {label} 解析出 {len(items)} 条，超过预期上限 {cap}，"
                  f"多余 {len(items) - cap} 条被丢弃：{[x['zh'] for x in items[cap:]]}")
        return items[:cap]

    limits = trunc_tagged([l for l in limits if l["zh"] and "名称" not in l["zh"] and "CAS" not in l["zh"]], 20, "限量表")
    banned = trunc_tagged([b for b in banned if b["zh"] and "名称" not in b["zh"] and "CAS" not in b["zh"]
                           and "Cat4" not in b["zh"] and "清单" not in b["zh"]], 9, "禁用表")
    natural = trunc_tagged([x for x in natural if "原料" not in x["zh"] and "CAS" not in x["zh"]], 2, "天然精油表")
    return {"source": "数据层/IFRA 51st Amendment Cat4香水禁用清单.xlsx", "amendment": "IFRA 51st Amendment",
            "limits": limits, "banned": banned, "natural": natural}


# ---------------------------------------------------------------- 3) CAS 词典
def norm_cas(cas: str) -> str:
    c = re.sub(r"\s+", "", cas or "")
    return c


def build_ingredients():
    specs = [("天然香料cas.xlsx", "natural"), ("合成香料CAS.xlsx", "synthetic"), ("香精 水溶性及油溶性香精CAS.xlsx", "fragrance")]
    entries, seen = [], set()
    for fname, src in specs:
        rows = xlsx_rows(DATA_DIR / fname)
        for cells in rows[1:]:
            vals = [cells.get(c, "") for c in ("A", "B", "C", "D")]
            cas = norm_cas(vals[0])
            zh = vals[1].strip()
            if not cas and not zh:
                continue
            if zh in ("中文名", "CAS") or cas in ("CAS",):
                continue
            key = (cas, zh)
            if key in seen:
                continue
            seen.add(key)
            entries.append({"cas": cas, "zh": zh, "en": vals[2].strip(), "formula": vals[3].strip(), "source": src})
    return {"source": "数据层/天然香料cas.xlsx + 合成香料CAS.xlsx + 香精CAS.xlsx", "entries": entries}


# ---------------------------------------------------------------- 4) 26 种致敏香料（EU 标注清单）
def build_allergens26():
    rows = xlsx_rows(DATA_DIR / "表格26种致敏香料.xlsx")
    items = []
    for cells in rows:
        if not cells.get("B") or not cells.get("C"):
            continue
        if cells["B"] in ("INCI 英文名",) or cells["C"] in ("中文通用名",):
            continue
        cas = re.sub(r"[‒‑–—\u2010-\u2015]+", "-", cells.get("D", "").strip())
        try:
            no = int(str(cells.get("A", "0")).strip() or 0)
        except ValueError:
            print(f"WARN: EU26 序号列非数字 {cells.get('A')!r}（{cells.get('C','').strip()}），按 0 记")
            no = 0
        items.append({
            "no": no,
            "inci": cells["B"].strip(),
            "zh": cells["C"].strip(),
            "cas": cas,
            "note": cells.get("E", "").strip(),
        })
    return {"source": "数据层/表格26种致敏香料.xlsx", "items": items[:26]}


# ---------------------------------------------------------------- 5) IgE Ⅰ 型速发材料
def build_ige():
    rows = xlsx_rows(DATA_DIR / "IgE致敏原表格.xlsx")
    items = []
    category = ""
    for cells in rows:
        only_b = [k for k in cells if k != "A"]
        if only_b == ["B"] and cells.get("B", "").strip().endswith(("类:", "类：", "类")):
            category = cells["B"].strip().rstrip(":：")
            continue
        if not cells.get("B") or not cells.get("C"):
            continue
        if cells["B"].strip() in ("原料中文名", "原料类型"):
            continue
        items.append({
            "category": category,
            "zh": cells["B"].strip(),
            "en": cells.get("C", "").strip(),
            "type": cells.get("D", "").strip(),
            "families": cells.get("E", "").strip(),
            "risk": cells.get("F", "").strip(),
            "note": cells.get("G", "").strip(),
        })
    return {"source": "数据层/IgE致敏原表格.xlsx", "items": items}


# ---------------------------------------------------------------- 6) 香材词典（天然 + 合成单体）
def build_materials():
    paras = [t for _s, t in docx_paragraphs(DATA_DIR / "香水成分数据及过敏香料.docx")]
    natural: list[str] = []
    synthetic: dict[str, list[str]] = {}
    state = None
    category = ""
    for t in paras:
        t = t.strip()
        if not t:
            continue
        if t.startswith("天然香料"):
            state = "natural"
            continue
        if t.startswith("合成单体香料"):
            state = "synthetic"
            continue
        if t.startswith(("辅料分类", "微量添加物", "防腐剂", "螯合剂", "光稳定剂")):
            state = None
            continue
        if state == "natural" and len(t) <= 8 and not re.search(r"[：:（）()]", t) and not re.match(r"^.{1,3}类(香料|)$", t):
            natural.append(t)
        elif state == "synthetic":
            if t.endswith("单体") and len(t) <= 14:
                category = t
                synthetic.setdefault(category, [])
            elif category and re.search(r"[、,，]", t):
                synthetic[category].extend(x.strip() for x in re.split(r"[、,，]\s*", t) if x.strip())
    return {
        "source": "数据层/香水成分数据及过敏香料.docx",
        "natural": natural,
        "synthetic": synthetic,
        "syntheticCount": sum(len(v) for v in synthetic.values()),
    }


# ---------------------------------------------------------------- 7) 共享毒理表（前后端共读，替代 TS/Py 双份内嵌）
TOX_DATA = [
    # keys 匹配键 | nesil μg/cm² | source 逐条出处 | k25 成分级氧化速率(25°C/天)
    {"keys": ["limonene", "柠檬烯"], "zh": "柠檬烯", "nesil": 10000, "source": "RIFM/Api et al. 2008（LLNA EC3 换算）", "k25": 0.0021},
    {"keys": ["linalool", "芳樟醇"], "zh": "芳樟醇", "nesil": 15000, "source": "RIFM 安全评估（Api et al. 2017 更新）", "k25": 0.0015},
    {"keys": ["citral", "柠檬醛"], "zh": "柠檬醛", "nesil": 1400, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["coumarin", "香豆素"], "zh": "香豆素", "nesil": 3500, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["eugenol", "丁香酚"], "zh": "丁香酚", "nesil": 5900, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["isoeugenol", "异丁香酚"], "zh": "异丁香酚", "nesil": 250, "source": "RIFM/Api et al. 2008（HRIPT）", "k25": None},
    {"keys": ["geraniol", "香叶醇"], "zh": "香叶醇", "nesil": 11800, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["citronellol", "香茅醇"], "zh": "香茅醇", "nesil": 29500, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["vanillin", "香兰素"], "zh": "香兰素", "nesil": 5314, "source": "RIFM 安全评估", "k25": None},
    {"keys": ["benzylalcohol", "苯甲醇"], "zh": "苯甲醇", "nesil": 5900, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["cinnamal", "肉桂醛"], "zh": "肉桂醛", "nesil": 591, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["cinnamylalcohol", "肉桂醇"], "zh": "肉桂醇", "nesil": 3000, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["farnesol", "法尼醇"], "zh": "法尼醇", "nesil": 2700, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["benzylsalicylate", "水杨酸苄酯"], "zh": "水杨酸苄酯", "nesil": 17700, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["benzylacetate", "乙酸苄酯"], "zh": "乙酸苄酯", "nesil": None, "source": None, "k25": None},
    {"keys": ["hexylcinnamal", "己基肉桂醛"], "zh": "己基肉桂醛", "nesil": 23600, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["amylcinnamal", "戊基肉桂醛"], "zh": "戊基肉桂醛", "nesil": 23600, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["citronellylacetate", "乙酸香茅酯"], "zh": "乙酸香茅酯", "nesil": None, "source": None, "k25": None},
    {"keys": ["geranylacetate", "乙酸香叶酯"], "zh": "乙酸香叶酯", "nesil": None, "source": None, "k25": None},
    {"keys": ["benzaldehyde", "苯甲醛"], "zh": "苯甲醛", "nesil": 590, "source": "RIFM/Api et al. 2008", "k25": None},
    {"keys": ["butylphenylmethylpropional", "铃兰醛", "lilial"], "zh": "铃兰醛", "nesil": 4100, "source": "RIFM（EU 2022 禁用）", "k25": None},
    {"keys": ["hydroxyisohexyl", "新铃兰醛", "lyral"], "zh": "新铃兰醛（海葵醛）", "nesil": 4000, "source": "RIFM（EU 2021 禁用）", "k25": None},
]

SAF_DEFAULT = 100
DEMO_PENALTY = 3


def build_tox():
    return {
        "source": "RIFM/Api et al. 2008 系安全评估（经旧库 71 条文献级提取）；逐条 RIFM 报告编号待补（TODO 2-1）",
        "saF": SAF_DEFAULT,
        "demoPenalty": DEMO_PENALTY,
        "items": [dict(t) for t in TOX_DATA],
    }


def main():
    if not DATA_DIR.exists():
        die(f"数据层目录不存在：{DATA_DIR}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    perfumes = build_perfumes()
    ifra = build_ifra()
    ingredients = build_ingredients()
    allergens26 = build_allergens26()
    ige = build_ige()
    materials = build_materials()

    (OUT_DIR / "perfumes.json").write_text(json.dumps(perfumes, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "ifra.json").write_text(json.dumps(ifra, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "ingredients.json").write_text(json.dumps(ingredients, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "allergens26.json").write_text(json.dumps(allergens26, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "ige.json").write_text(json.dumps(ige, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "materials.json").write_text(json.dumps(materials, ensure_ascii=False, indent=2), "utf-8")
    (OUT_DIR / "tox.json").write_text(json.dumps(build_tox(), ensure_ascii=False, indent=2), "utf-8")

    print(f"perfumes: {len(perfumes['perfumes'])} 款")
    for p in perfumes["perfumes"][:3]:
        print(f"  - {p['brand']} {p['name']} ({p['familyZh']}/{p['familyKey']}) 前中后 {tuple(len(l['notes']) for l in p['pyramid'])} 关键词={p['keywords'][:20]}")
    print(f"ifra: limits={len(ifra['limits'])} banned={len(ifra['banned'])} natural={len(ifra['natural'])}")
    for b in ifra["banned"]:
        print(f"  禁 {b['zh']} cas={b['cas']} {b['control']} {b['reason'][:24]}")
    print(f"ingredients: {len(ingredients['entries'])} 条")
    print(f"allergens26: {len(allergens26['items'])} 条（EU 标注清单）")
    print(f"ige: {len(ige['items'])} 条（Ⅰ 型速发材料）")
    for it in ige["items"][:3]:
        print(f"  IgE {it['zh']} [{it['category']}] {it['risk']}")
    print(f"materials: 天然 {len(materials['natural'])} + 合成 {materials['syntheticCount']}（{len(materials['synthetic'])} 类）")
    print(f"tox: {len(TOX_DATA)} 条（documented {sum(1 for t in TOX_DATA if t['nesil'])} / demo {sum(1 for t in TOX_DATA if not t['nesil'])}）")
    if len(perfumes["perfumes"]) != 12:
        print(f"WARN: 期望 12 款，实际 {len(perfumes['perfumes'])}")
    if len(ifra["limits"]) != 20 or len(ifra["banned"]) != 9:
        print(f"WARN: IFRA 期望 20/9/2，实际 {len(ifra['limits'])}/{len(ifra['banned'])}/{len(ifra['natural'])}")


if __name__ == "__main__":
    main()
