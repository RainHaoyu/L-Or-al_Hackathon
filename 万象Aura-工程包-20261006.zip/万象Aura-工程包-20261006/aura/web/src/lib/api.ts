/**
 * 后端客户端（aura/api，默认 http://localhost:8001/api/v1）
 * 设计要点：短超时 + 任何失败静默回退本地引擎（演示日断网双保险）。
 * 类型全部来自 api-types.ts（openapi 自动生成，勿手写）。
 */

import type { AnalyzeRequest, AnalyzeResponse, HealthResponse, ImageRecognitionResponse } from './api-types'

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? 'http://localhost:8001/api/v1'

/**
 * 分档超时（改进清单 1-2）：后端 LLM 实测 normal/sensitive ≈3-4.5s、anosmia ≈7.7-9.6s。
 * 前端超时必须 > 后端单档超时 × 档数（qwen-max → qwen-plus 两级兜底）。
 */
const TIMEOUT_FAST = 2500
const TIMEOUT_ANALYZE_NORMAL = 7000
const TIMEOUT_ANALYZE_ANOSMIA = 13000
const TIMEOUT_RECOGNITION = 12000

async function req<T>(path: string, init?: RequestInit, timeout = TIMEOUT_FAST): Promise<T> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), timeout)
  try {
    const r = await fetch(`${BASE}${path}`, { ...init, signal: ctrl.signal })
    if (!r.ok) throw new Error(`HTTP ${r.status}`)
    return (await r.json()) as T
  } finally {
    clearTimeout(timer)
  }
}

export const api = {
  baseUrl: BASE,

  health: () => req<HealthResponse>('/health'),

  recognizeImage: (image: string, filename: string) =>
    req<ImageRecognitionResponse>('/recognition/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image, filename }),
    }, TIMEOUT_RECOGNITION),

  recognizeBarcode: (code: string) =>
    req<ImageRecognitionResponse>('/recognition/barcode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    }),

  analyze: (payload: AnalyzeRequest) =>
    req<AnalyzeResponse>('/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }, payload.mode === 'anosmia' ? TIMEOUT_ANALYZE_ANOSMIA : TIMEOUT_ANALYZE_NORMAL),
}
