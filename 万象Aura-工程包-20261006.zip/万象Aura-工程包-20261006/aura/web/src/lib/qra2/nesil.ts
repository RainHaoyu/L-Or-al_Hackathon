/**
 * QRA2 · NESIL/SAF 毒理参数（数据源：src/data/tox.json，与后端共读，勿在此手改数值）
 * NESIL 单位 μg/cm²，来源 RIFM/Api et al. 2008 系；无文献值者 demo_estimate：
 * AEL 施加 ÷ demoPenalty 保守惩罚并标 indicative（数据诚实原则）。
 * ⚠️ 双引擎同步警示：改 tox.json 无需同步代码；但改本文件或 engine.ts 的算法时，
 *    必须同步 api/app/modules/qra2.py 并重跑两端测试（改进清单 3-1）。
 */

import toxFile from '../../data/tox.json'

export interface ToxEntry {
  keys: string[]
  zh: string
  nesil: number | null
  source: string | null
  k25: number | null
}

const FILE = toxFile as unknown as { saF: number; demoPenalty: number; items: ToxEntry[] }

export const TOX: ToxEntry[] = FILE.items
export const SAF = FILE.saF
export const SAF_BASIS = '种间 10 × 个体 10（IFRA leave-on 默认）'
export const DEMO_PENALTY = FILE.demoPenalty

function norm(s: string): string {
  return s.toLowerCase().replace(/[\s\-–]/g, '')
}

/** 最长优先匹配（防长名包含短名误判，如 Isoeugenol ≠ Eugenol，改进清单 1-5）。
 *  键长下限按文字自适应：ASCII 键 ≥4（防 'oil' 之类误触），中文键 ≥2 */
export function lookupTox(name: string): ToxEntry | null {
  const n = norm(name)
  let best: ToxEntry | null = null
  let bestLen = 0
  for (const t of TOX) {
    for (const k of t.keys) {
      const nk = norm(k)
      const min = /[a-z]/i.test(k) ? 4 : 2
      if (nk.length >= min && n.includes(nk) && nk.length > bestLen) {
        best = t
        bestLen = nk.length // 以「实际命中的键长」排序（而非条目最长键），否则英文长键会劫持中文命中
      }
    }
  }
  return best
}
