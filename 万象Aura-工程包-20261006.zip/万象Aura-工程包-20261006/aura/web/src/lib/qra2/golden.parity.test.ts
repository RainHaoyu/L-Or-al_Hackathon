/**
 * 双引擎 golden 对拍（前端侧）：与后端 pytest（api/tests/test_qra2_numerics.py）
 * 共读同一份 aura/golden/qra2-cases.json。任何一端算法漂移（如曾经的 normal_inv
 * 括号 bug、beta 查表插值漂移）都会在此立即变红。
 * 文件由 scripts/gen_golden.mts 生成；改分布参数后重新生成并跑两端测试。
 */
import { describe, expect, it } from 'vitest'
import golden from '../../../../golden/qra2-cases.json'
import { normalInv, betaInv, sampleCEL } from './distributions'

const G = golden as {
  normalInv: { u09: number; u05: number; u01: number }
  betaInv: { u05: number; u09: number }
  cases: { seed: number; concPct: number; aggregateFactor: number; p50: number; p90: number; p99: number }[]
}

describe('双引擎 golden 对拍', () => {
  it('normalInv 参照值一致', () => {
    expect(normalInv(0.9)).toBeCloseTo(G.normalInv.u09, 12)
    expect(normalInv(0.5)).toBeCloseTo(G.normalInv.u05, 12)
    expect(normalInv(0.1)).toBeCloseTo(G.normalInv.u01, 12)
  })
  it('betaInv 参照值一致', () => {
    expect(betaInv(0.5, 20, 2)).toBeCloseTo(G.betaInv.u05, 9)
    expect(betaInv(0.9, 20, 2)).toBeCloseTo(G.betaInv.u09, 9)
  })
  it('同种子分位数逐组一致（本引擎应为逐位）', () => {
    expect(G.cases.length).toBeGreaterThanOrEqual(5)
    for (const c of G.cases) {
      const s = sampleCEL({ concPct: c.concPct, seed: c.seed, aggregateFactor: c.aggregateFactor })
      expect(s.p50).toBe(c.p50)
      expect(s.p90).toBe(c.p90)
      expect(s.p99).toBe(c.p99)
    }
  })
})
