/**
 * 三份原始数据层整合验收：EU26 标注清单 / IgE 速发材料 / 香材词典
 */
import { describe, expect, it } from 'vitest'
import { lookupTox, TOX } from './qra2/nesil'
import { IFRA, lookupEu26, lookupIge } from './aura'
import {
  EU26,
  IGE,
  MATERIALS,
  buildIngredients,
  evaluate,
  matchManualIngredient,
  parseManualIngredients,
} from './aura'

describe('数据层完整性', () => {
  it('EU26 = 26 条且 CAS 已归一（不含不换行连字符）', () => {
    expect(EU26.length).toBe(26)
    expect(EU26.every((a) => !a.cas.includes('\u2011'))).toBe(true)
    expect(EU26.some((a) => a.zh === '大茴香醇')).toBe(true)
  })
  it('IgE = 10 条且无表头污染行', () => {
    expect(IGE.length).toBe(10)
    expect(IGE.every((g) => g.zh !== '原料类型' && g.zh !== '原料中文名')).toBe(true)
    expect(IGE.some((g) => g.zh === '安息香树脂')).toBe(true)
  })
  it('香材词典：天然 72 + 合成 76（8 类）', () => {
    expect(MATERIALS.natural.length).toBe(72)
    expect(MATERIALS.syntheticCount).toBe(76)
    expect(Object.keys(MATERIALS.synthetic).length).toBe(8)
    expect(MATERIALS.natural).toContain('鸢尾')
  })
})

describe('手动通道新匹配分支', () => {
  const m = (s: string) => matchManualIngredient(parseManualIngredients(s)[0], 'healthy')
  it('大茴香醇 → EU 26 标注清单（黄）', () => {
    const r = m('Anisyl alcohol')
    expect(r.kind).toBe('eu26')
    expect(r.level).toBe('mid')
    expect(r.note).toContain('0.01%')
  })
  it('安息香 → IgE Ⅰ 型速发（树脂类）', () => {
    const r = m('安息香')
    expect(r.kind).toBe('ige')
    expect(r.zh).toBe('安息香树脂')
  })
  it('鸢尾 → 天然香材词典', () => {
    const r = m('鸢尾')
    expect(r.kind).toBe('material')
    expect(r.gate).toBe('天然香材')
  })
  it('IFRA 限值优先级高于 EU26（苯甲醇走限值分支）', () => {
    const r = m('Benzyl Alcohol')
    expect(r.kind).toBe('limit')
  })
})

describe('判定与报告 IgE 集成', () => {
  it('一千零一夜 × 鼻炎 → IgE 速发理由 + 报告 IgE 行', () => {
    const v = evaluate('rhinitis', 'shalimar', 0)
    expect(v.reasons.some((x) => x.includes('IgE') && x.includes('安息香'))).toBe(true)
    const rows = buildIngredients('shalimar', 0, 'rhinitis')
    const igeRows = rows.filter((r) => r.gate === 'IgE Ⅰ 型速发')
    expect(igeRows.length).toBeGreaterThanOrEqual(2)
  })
})

describe('1-4 禁用 CAS 校验位闸门', () => {
  it('所有落盘 CAS 要么校验位合法，要么显式置 null（不允许静默错误值）', async () => {
    // await 动态导入：此前未 await，断言在测试同步结束后才执行，失败也不会红（假绿）
    const { default: d } = await import('../data/ifra.json')
    const cs = (cas: string) => {
      const digits = cas.replace(/\D/g, '')
      const body = digits.slice(0, -1)
      const check = Number(digits.slice(-1))
      const total = [...body].reverse().reduce((s, ch, i) => s + Number(ch) * (i + 1), 0)
      return total % 10 === check
    }
    for (const b of d.banned as { cas: string | null; casValid: boolean; zh: string }[]) {
      expect(b.cas === null || cs(b.cas), `${b.zh} 的 CAS ${b.cas} 校验位非法`).toBe(true)
      if (b.cas === null) expect(b.casValid).toBe(false)
    }
    const muskXylene = (d.banned as { zh: string; cas: string | null }[]).find((b) => b.zh === '二甲苯麝香')
    expect(muskXylene?.cas).toBe('81-15-2')
    const lyral = (d.banned as { zh: string; cas: string | null }[]).find((b) => b.zh === '海葵醛')
    expect(lyral?.cas).toBe('31906-04-4')
  })
})

describe('1-5 自探测：用自己名字查自己（最长优先）', () => {
  it('IFRA 限量 20 条 zh 自查命中自身', () => {
    // α-己基肉桂醛与毒理表「己基肉桂醛」为同一物质（INCI: Hexyl Cinnamal），按化学等价断言
    const EQUIV: Record<string, string> = { 'α-己基肉桂醛': '己基肉桂醛', 'd-柠檬烯': '柠檬烯' }
    for (const l of IFRA.limits) {
      const byZh = matchZh(l.zh)
      expect(byZh, `${l.zh} 应命中自身`).toBe(EQUIV[l.zh] ?? l.zh)
    }
    function matchZh(zh: string): string | undefined {
      // 复用手册路径：手动匹配的 limit 分支
      const r = matchManualIngredient({ raw: zh, name: zh, pct: null }, 'healthy')
      return r.kind === 'limit' ? r.zh : undefined
    }
  })
  it('EU26/IgE/毒理表自探测 100% 命中自身', () => {
    for (const a of EU26) {
      if (a.zh === '苯甲醛' || IFRA_LIMITED.has(a.zh)) continue // 与 IFRA 限值同名者优先走限值分支（更严）
      expect(lookupEu26(a.zh)?.zh ?? lookupEu26(a.inci)?.zh, `${a.zh}`).toBe(a.zh)
    }
    for (const g of IGE) {
      expect(lookupIge(g.zh)?.zh, `${g.zh}`).toBe(g.zh)
    }
    for (const t of TOX) {
      expect(lookupTox(t.zh)?.zh ?? lookupTox(t.keys[t.keys.length - 1])?.zh, `${t.zh}`).toBe(t.zh)
    }
  })
  it('最长优先：Isoeugenol 不再误判为 Eugenol（危险方向）', () => {
    expect(lookupTox('Isoeugenol')?.zh).toBe('异丁香酚')
    expect(lookupTox('Eugenol')?.zh).toBe('丁香酚')
    expect(lookupTox('alpha-Hexyl cinnamal')?.zh).toBe('己基肉桂醛')
    expect(lookupTox('Amyl cinnamal')?.zh).toBe('戊基肉桂醛')
  })
})

const IFRA_LIMITED = new Set([
  '柠檬醛', '香豆素', '香叶醇', '香茅醇', '丁香酚', '异丁香酚', '肉桂醛', '肉桂醇',
  '香兰素', '芳樟醇', '法尼醇', '苯甲醇', '苯甲醛', '戊基肉桂醛', '水杨酸苄酯', '乙酸苄酯',
])
