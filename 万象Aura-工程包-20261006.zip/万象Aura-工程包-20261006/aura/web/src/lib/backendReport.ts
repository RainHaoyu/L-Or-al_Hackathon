/**
 * 后端 /analyze 响应 → 报告页视图模型（P0-4 接线）。
 *
 * 架构：后端优先，本地降级。报告页优先渲染后端实算（含 LLM 通感文案），
 * 断网/超时/输入已变更时回退本地引擎（与后端同算法，golden 对拍保证数值一致）。
 * 后端 AnalyzeData 与本地 Verdict/IngredientRow 形状同源（openapi 生成），
 * 此处只做窄化与缺省处理，不做数值改写。
 */
import type { AnalyzeData } from './api-types'
import type { Evidence, IngredientRow, RiskLevel, Verdict } from './aura'

export interface BackendPanelView {
  label: string
  name: string
  concPct: number
  ael: number | null
  p50: number | null
  p90: number | null
  p99: number | null
  marginPoint: number | null
  marginP99: number | null
  marginPolicy: number | null
  policy: string
  tPop: number
}

export interface BackendReportView {
  verdict: Verdict
  rows: IngredientRow[]
  panel: BackendPanelView
  oxidation: { d: number; months: number; storage: string }
  synesthesia: { text: string; model: string; isLlm: boolean }
}

/** 窄化后端枚举字段（openapi 生成类型为宽 string 时收敛到本地联合类型） */
function asLevel(v: string): RiskLevel {
  return v === 'high' || v === 'mid' ? v : 'low'
}

function asEvidence(v: string): Evidence {
  return v === 'indicative' || v === 'insufficient' ? v : 'documented'
}

export function backendReportView(d: AnalyzeData): BackendReportView {
  return {
    verdict: {
      level: asLevel(d.verdict.level),
      headline: d.verdict.headline,
      reasons: d.verdict.reasons,
      advice: d.verdict.advice,
      dominantGate: d.verdict.dominantGate,
      hits: d.verdict.hits,
    },
    rows: d.ingredients.map((r) => ({
      inci: r.inci,
      zh: r.zh,
      conc: r.conc,
      level: asLevel(r.level),
      gate: r.gate,
      evidence: asEvidence(r.evidence),
      note: r.note,
      limitPct: r.limitPct ?? null,
    })),
    panel: {
      label: d.panel.label,
      name: d.panel.name,
      concPct: d.panel.concPct,
      ael: d.panel.ael ?? null,
      p50: d.panel.p50 ?? null,
      p90: d.panel.p90 ?? null,
      p99: d.panel.p99 ?? null,
      marginPoint: d.panel.marginPoint ?? null,
      marginP99: d.panel.marginP99 ?? null,
      marginPolicy: d.panel.marginPolicy ?? null,
      policy: d.panel.policy,
      tPop: d.panel.tPop,
    },
    oxidation: { d: d.oxidation.d, months: d.oxidation.months, storage: d.oxidation.storage },
    synesthesia: { text: d.synesthesia.text, model: d.synesthesia.model, isLlm: d.synesthesia.isLlm },
  }
}
