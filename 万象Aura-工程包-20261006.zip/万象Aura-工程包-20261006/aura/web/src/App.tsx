import { useEffect } from 'react'
import { Link, Routes, Route, useLocation } from 'react-router'
import { AppProvider } from './lib/state'
import { TopNav } from './components/TopNav'
import Home from './pages/Home'
import Report from './pages/Report'
import Vision from './pages/Vision'

/** 路由切换回到页面顶部；带 hash（如 /#analyze）则滚动到对应区块 */
function ScrollToTop() {
  const { pathname, hash } = useLocation()
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.slice(1))
      if (el) {
        el.scrollIntoView()
        return
      }
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior })
  }, [pathname, hash])
  return null
}

function NotFound() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-24 text-center sm:px-6">
      <p className="font-display text-6xl text-gold">404</p>
      <h1 className="font-display mt-4 text-3xl">这一页还没有香气</h1>
      <p className="mt-3 text-sm text-muted-foreground">地址可能输错了。回到首页重新开始一次分析。</p>
      <Link
        to="/"
        className="focus-visible-strong mt-8 inline-flex min-h-12 items-center rounded-full bg-ink px-7 font-medium text-paper"
      >
        回到首页
      </Link>
    </main>
  )
}

export default function App() {
  return (
    <AppProvider>
      <ScrollToTop />
      <TopNav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/report" element={<Report />} />
        <Route path="/vision" element={<Vision />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AppProvider>
  )
}
