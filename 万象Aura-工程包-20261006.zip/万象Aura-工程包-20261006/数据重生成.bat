@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 万象 Aura - 数据层重生成
cd /d "%~dp0"

rem ============================================================
rem   数据层重生成：数据层/（8 份原始 xlsx/docx）→ aura/web/src/data/*.json
rem   幂等可重跑；生成后重启 一键启动.bat 即生效（数据在启动时加载）。
rem   使用系统任意 Python 3.10+（纯标准库，无需装依赖）。
rem ============================================================

if not exist "数据层" (
  echo [错误] 未找到 数据层 目录——工程包根目录下应存放 8 份原始数据文件。
  pause
  exit /b 1
)

set "PYC=py"
py --version >nul 2>nul || set "PYC="
if not defined PYC (
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYC set "PYC=%%i"
)
if not defined PYC (
  echo [错误] 未检测到 Python，请先安装 3.10+。
  pause
  exit /b 1
)

echo 用 数据层/ 原始文件重新生成 7 份 JSON...
"%PYC%" "aura\web\scripts\build_data.py"
if errorlevel 1 (
  echo [失败] 生成中断，请查看上方告警（如 CAS 校验位 WARN 需人工核对源表）。
) else (
  echo [完成] aura\web\src\data\ 已更新。重启 一键启动.bat 生效。
)
pause
