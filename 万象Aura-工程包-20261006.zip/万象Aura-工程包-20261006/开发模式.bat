@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 万象 Aura - 开发模式（改代码用）
cd /d "%~dp0"

rem ============================================================
rem   开发模式：改前端/后端源码时用（热更新）。
rem   需要额外安装 Node.js LTS（https://nodejs.org/zh-cn）。
rem   仅看演示请用 一键启动.bat，无需 Node。
rem   会开两个窗口：后端 8001（--reload 热更）+ 前端 5173（vite 热更）。
rem ============================================================

rem ---- 后端窗口（复用一键启动的依赖引导）----
start "万象Aura后端(开发)" cmd /c call "%~dp0一键启动.bat"
rem 等 2 秒让后端先起，前端代理目标更稳
timeout /t 2 /nobreak >nul

rem ---- 前端 ----
cd /d "%~dp0aura\web"
where node >nul 2>nul || (
  echo [错误] 开发模式需要 Node.js LTS：https://nodejs.org/zh-cn
  echo        仅看演示请直接双击 一键启动.bat
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo 首次运行：安装前端依赖（约 2-5 分钟）...
  call npm install
  if errorlevel 1 (
    echo npm 安装失败，换国内镜像重试...
    call npm install --registry=https://registry.npmmirror.com
    if errorlevel 1 (echo [错误] 前端依赖安装失败 & pause & exit /b 1)
  )
)
echo 前端开发服务启动：http://localhost:5173 （后端 API 在 8001）
start "" "http://localhost:5173/"
call npm run dev
pause
