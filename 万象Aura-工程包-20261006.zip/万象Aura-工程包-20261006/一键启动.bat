@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 万象 Aura - 一键启动
cd /d "%~dp0aura\api"

rem ============================================================
rem   万象 Aura 一键启动（Windows 演示主入口）
rem   唯一前提：Python 3.11+（含 3.14）。无需 Node.js。
rem   首次运行自动创建虚拟环境并离线安装依赖（vendor/ 内置全量 wheel，
rem   覆盖 Python 3.11-3.14；离线未命中时自动联网，再失败换清华镜像）。
rem   之后每次启动为秒级。关闭本窗口即停止服务。
rem ============================================================

rem ---- 1. 定位 Python（py 启动器优先，其次 PATH 里的 python）----
set "PYC=py"
py --version >nul 2>nul || set "PYC="
if not defined PYC (
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYC set "PYC=%%i"
)
if not defined PYC (
  echo [错误] 未检测到 Python。请安装 3.11 或更高版本：
  echo        https://www.python.org/downloads/windows/
  echo        安装时务必勾选 “Add python.exe to PATH”。
  pause
  exit /b 1
)

rem ---- 2. 端口探测：8001 被占用则退到 8010 ----
set "PORT=8001"
netstat -ano 2>nul | findstr ":8001" | findstr "LISTENING" >nul && set "PORT=8010"

rem ---- 3. 首次运行：建 venv + 装依赖（.venv\.deps_ok 为完成标记）----
if not exist ".venv\.deps_ok" (
  echo 首次运行：创建虚拟环境并安装依赖，约 1 分钟...
  if not exist ".venv\Scripts\python.exe" (
    "%PYC%" -m venv .venv || (echo [错误] 虚拟环境创建失败 & pause & exit /b 1)
  )
  echo [1/3] 尝试离线安装（vendor 内置 wheel，无需联网）...
  ".venv\Scripts\python.exe" -m pip install --no-index --find-links vendor -r requirements.txt -q
  if errorlevel 1 (
    echo [2/3] 离线未命中（可能 Python 版本不在 3.11-3.14），改走在线安装...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt -q
    if errorlevel 1 (
      echo [3/3] 在线失败，尝试清华镜像...
      ".venv\Scripts\python.exe" -m pip install -r requirements.txt -q -i https://pypi.tuna.tsinghua.edu.cn/simple
      if errorlevel 1 (
        echo [错误] 依赖安装失败：请检查网络，或把 vendor 目录与当前 Python 版本的匹配情况反馈给团队。
        pause
        exit /b 1
      )
    )
  )
  type nul > ".venv\.deps_ok"
  echo 依赖就绪。
)

rem ---- 4. 启动（单进程同时服务页面与 API）+ 打开浏览器 ----
echo.
echo ============================================================
echo   万象 Aura 启动中：http://127.0.0.1:%PORT%
echo   页面与 API 由同一进程提供；关闭本窗口（或 Ctrl+C）即停止
echo ============================================================
echo.
start "" "http://127.0.0.1:%PORT%/"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port %PORT%
echo.
echo 服务已停止。
pause
